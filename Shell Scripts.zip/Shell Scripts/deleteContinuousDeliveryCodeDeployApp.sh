echo "Beginning of script"

echo "Deleting application"
aws deploy delete-application --application-name CRMMavericksProject

echo "End of script"