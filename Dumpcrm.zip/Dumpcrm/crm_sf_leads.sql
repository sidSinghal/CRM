CREATE DATABASE  IF NOT EXISTS `crm_sf` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `crm_sf`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: crm_sf
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leads` (
  `LeadID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LeadFirstName` varchar(45) NOT NULL,
  `LeadLastName` varchar(45) NOT NULL,
  `AccountID` int(10) unsigned DEFAULT NULL,
  `ProductID` int(10) unsigned DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `Phonenumber` varchar(20) DEFAULT NULL,
  `Lead_opportunity` varchar(45) NOT NULL,
  PRIMARY KEY (`LeadID`),
  UNIQUE KEY `idLeads_UNIQUE` (`LeadID`),
  KEY `acctidfk_idx` (`AccountID`),
  KEY `prodidfk_idx` (`ProductID`)
) ENGINE=InnoDB AUTO_INCREMENT=10011 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (10001,'gazel','Sham',1001,10001,'Active ','6338393789','Lead'),(10002,'Xaner','Cage',1001,10005,'Active ','7898767668','Lead'),(10003,'Nancy','Mine',1003,10002,'Active ','5678976576','Opportunity'),(10004,'Guanda','Martin',1003,10007,'Active ','7889889789','Opportunity'),(10005,'Gwen','Stafani',1000,10002,'Active ','7898778978','Lead'),(10006,'Gautham','Gulathi',1005,10007,'Active ','9876567808','Opportunity'),(10007,'Girija','Manchandani',1002,10009,'Active ','8786435677','Lead'),(10008,'Tricia','Gordon',1006,10005,'Active ','7883086768','Lead'),(10009,'Mandy','Chikita',1007,10005,'Active ','7889990878','Lead'),(10010,'Maitree','Chirantimatt',1002,10005,'Active ','8787879908','Lead');
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-15 22:26:14
