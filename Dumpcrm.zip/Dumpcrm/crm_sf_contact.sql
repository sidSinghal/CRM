CREATE DATABASE  IF NOT EXISTS `crm_sf` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `crm_sf`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: crm_sf
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `contactId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ContactFirstName` varchar(45) DEFAULT NULL,
  `ContactLastName` varchar(45) DEFAULT NULL,
  `AccountID` int(11) DEFAULT NULL,
  `Account Name` varchar(45) DEFAULT NULL,
  `EmailID` varchar(100) DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`contactId`),
  UNIQUE KEY `contactId_UNIQUE` (`contactId`)
) ENGINE=InnoDB AUTO_INCREMENT=10012 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (10001,'Charles','Manchester',1003,'Mindtree','charles.manchester@mindtree.com','Active'),(10002,'Mandy','Malfrec',1005,'Mahindra','mandy.mlfrec@mahindra.com','Active'),(10003,'Manik','Jhajoria',1006,'Charles River','manik.j@cr.com','Active'),(10004,'Frank ','Josh',1003,'Mindtree','frank.josh@mindtree.com','Active'),(10005,'Shawn','Mendes',1003,'Mindtree','shawn.mendes@mindtree.com','Active'),(10006,'Jason','Flemingo',1003,'Mindtree','jason.flemingo@mindtree.com','Active'),(10007,'Brad','Chant',1009,'Emphasis','Chant.brad@emphasis.com','Active'),(10008,'Chalie','Brown',1009,'Emphasis','brown.charlie@emphasis.com','Active'),(10009,'George','Cloony',1008,'Ahold','cloony.george@ahold.com','Active'),(10010,'Robert','Downey',1008,'Ahold','downey.robert@ahold.com','Active'),(10011,'Will','Smith',1008,'Ahold','smith.will@ahold.com','Active');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-15 22:26:14
